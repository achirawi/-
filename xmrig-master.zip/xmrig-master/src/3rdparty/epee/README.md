epee -  is a small library of helpers, wrappers, tools and and so on, used to make my life easier.
